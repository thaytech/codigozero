CREATE DATABASE escola;

CREATE TABLE alunos(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR (100),
    idade INT,
    email VARCHAR(100)
    );